THANKS
======

Thank you to all of the contributors with code and patches to the SIP.js project, as well as to the JsSIP project, without which this would not be possible.

* [Sándor Balázs](https://github.com/sanyatuning)
* The [LiveNinja](https://www.liveninja.com) Team ([GitHub](https://github.com/liveninja))
* [Philipp Weissensteiner](https://github.com/wpp)
* [Rob Wu](https://github.com/Rob--W)
* [Sam Metson](https://github.com/Bat-o-matic)
* [Mike Chacon](https://github.com/sicdigital)
* [Sean Bright](https://github.com/seanbright)
* [Carlos Ruiz Diaz](https://github.com/caruizdiaz)
* [Destreyf](https://github.com/Destreyf)
* [Mark Roberts](https://github.com/markandrus)
* [Ryan Rowland](https://github.com/ryan-rowland)
* [Ben Langfeld](https://github.com/benlangfeld)
* [Gerik Bonaert](https://github.com/adaxi)
* [Max Rothstein](https://github.com/mrothstein)
* [zxcpoiu](https://github.com/zxcpoiu)
* [Pavlo Mykhalov](https://github.com/growtofill)
* [Microcow](https://github.com/Mirocow)
* [The RingCentral Team](https://github.com/ringcentral)
* [Jeremy Lainé](https://github.com/jlaine)
* [Matthieu Sieben](https://github.com/matthieusieben)
* [Dan Jenkins](https://github.com/danjenkins)
* [Vadym Yatsyuk](https://github.com/VadimDez)
* [Jim Greenberg](https://github.com/JimGreenberg)
* [andrew127](https://github.com/andrew127)

Much credit goes to the original authors of the JsSIP project.  Thank you to all.

* [Jose Millan](https://github.com/jmillan)
* [Inaki Baz Castillo](https://github.com/ibc)
* [Saul Ibarra Corretge](https://github.com/saghul)


Here is the list of contributors with code and patches to the JsSIP project. Thanks a lot to all.

* [vf1](https://github.com/vf1)
* [Pedro Kiefer](https://github.com/pedrokiefer)
* [Iwan Budi Kusnanto](https://github.com/iwanbk)
* Davide Corda
* [Anthony Minessale](https://github.com/FreeSWITCH)
* [Gavin Llewellyn](https://github.com/gavllew)
* [Julian Scheid](https://github.com/jscheid)


JsSIP Debian and Ubuntu packaging

* [Daniel Pocock](https://github.com/dpocock)
