# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 0.19.x   | :white_check_mark: |
| < 0.19.x   | :x:                |

## Reporting a Vulnerability

Please open an issue on github.
